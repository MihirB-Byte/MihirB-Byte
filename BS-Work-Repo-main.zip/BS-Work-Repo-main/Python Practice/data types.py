tpl={'sadfas':55,'dafasdf':66}
##tpl[2]='Chng'
print(type(tpl))

user_inputs=[]


user_inputs = [int(x) for x in input("Enter multiple values seperated with comma : ").split(" ")] #getting multiple values from the user seperated by space
print("the list is : " + str(user_inputs))








    