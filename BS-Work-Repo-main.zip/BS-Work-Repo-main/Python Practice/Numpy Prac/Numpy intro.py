import numpy as np

print(np.__version__)

a = np.array([1,2,3,4])
print (a)
print(a.dtype)
print(a.shape)
print(a.itemsize)